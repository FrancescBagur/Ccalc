A fitxers adjuntats trobareu : 
-Control de hores i tasques.
-Diagrama de gantt en pdf.